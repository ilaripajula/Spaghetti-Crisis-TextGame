package o1.adventure
import o1._
import scala.collection.mutable.Map

/** A `Player` object represents a player character controlled by the real-life user of the program.
  *
  * A player object's state is mutable: the player's location and possessions can change, for instance.
  *
  * @param startingArea  the initial location of the player */
class Player(startingArea: Area) {

  private var currentLocation = startingArea        // gatherer: changes in relation to the previous location
  private var quitCommandGiven = false   // one-way flag
  private var items = Map[String, Item]()
  private var money:Double = 6.99
  private var meal = false  // Win condition changes this to true
  private var honesty = true  //If the player does not pay before leaving alepa then the game ends in arrest.
  private var totalOwed = 0.0
  
  def drop(itemName:String):String  ={
    var option = items.get(itemName)
    if (option == None) 
       "You don't have that!" 
    else {
       this.currentLocation.addItem(option.head)
       totalOwed -= items.get(itemName).head.price //Updated to remove the item's price from totalOwed
       items.remove(itemName)
       "You drop the " + itemName +"."
    }
  }
  
  // Updated to allow the player to examine the amount of money they currently have.
  def examine(itemName: String): String = {
    var option = items.get(itemName)
    if (itemName == "wallet"){
      "I have "+ this.money + " euros on me right now."
    }else if (option.isEmpty) 
      "If you want to examine something, you need to pick it up first." 
    else 
      "You look closely at the " + option.head.name + ".\n" + option.head.description + "."
  }
  
  def get(itemName: String): String = {
    val x = this.currentLocation.removeItem(itemName)
    if (!x.isEmpty){
      items += itemName -> x.head
      totalOwed += items.get(itemName).head.price  // Add the price of the item to totalOwed
      "You pick up the " + itemName + "."
    }else{
       "There is no "+itemName+ " here to pick up."
    }
  }
  
  def has(itemName:String):Boolean = {
    if (items.get(itemName).isEmpty)
      false
    else
      true
  }

  def inventory:String = {
    if (items.isEmpty)
      "You are empty-handed."
    else{
    "You are carrying:" + items.map(p => "\n" + p._1).mkString("")
    }
  }
  
  /** Determines if the player has indicated a desire to quit the game. */
  def hasQuit = this.quitCommandGiven


  /** Returns the current location of the player. */
  def location = this.currentLocation


  /** The go method has been updated to include a condition that ends the game if the player decides to steal from Alepa*/
  def go(direction: String) = {
    
    if (this.currentLocation.name == "Checkout" && this.totalOwed != 0.0 && (direction == "back home" || direction == "to alepa")){
      this.honesty = false
      "You were caught stealing from Alepa. You tried to run pasta security guard but you were caught red-handed with " + "%1.2f".format(this.totalOwed) + " worth of goods. Now you're in jail, congratulations."
    
    }else{
      val destination = this.location.neighbor(direction)
      this.currentLocation = destination.getOrElse(this.currentLocation)
      if (destination.isDefined) "You go " + direction + "." else "You can't go " + direction + " from here."
    
    }
  }


  /** Causes the player to rest for a short while (this has no substantial effect in game terms).
    * Returns a description of what happened. */
  def rest() = {
    "You rest for a while. Better get a move on, though."
  }


  /** Signals that the player wants to quit the game. Returns a description of what happened within
    * the game as a result (which is the empty string, in this case). */
  def quit() = {
    this.quitCommandGiven = true
    ""
  }
  
  def hasCooked() = this.meal
  
  def isInJail() = this.honesty

  
  def use(input:String)= {
    if (input == "pot" && this.items.get("pot").isDefined){
      
      if (this.currentLocation.name == "The Kitchen"){

        if (this.items.contains("börk-börk ost") && this.items.contains("snellman's minced meat") && this.items.contains("barilla spaghetti")) {
          this.meal = true
          "It's perfect. It tastes... just like the real Täffä spaghetti."

        } else if (this.items.filterNot(_._1=="pot").filterNot(_._1 =="shopping list").size == 0) {
          "I'll need some ingredients to cook with first."

        } else {
          "Something isn't right. Either I really donked up these ingredients or I'm a really bad chef. Nah, it has to be the ingredients."

        }
      }else{
        "I can only use the pot in the kitchen. Where the stove is, yanno."
      }
    }else{
      "I can only 'use pot' if I have one."
    }
      
  }
  
  // Expected value game that increases your initial bet most of the time
  def slots(bet_String:String)= {
    if (bet_String.forall(_.isDigit)&& !bet_String.isEmpty()) {
      val bet = bet_String.toDouble

      if (bet > this.money) {
        "I need to take a loan for that to happen."

      } else if (bet < 0) {
        "I can't bet less than 0.0 euros, C'mon"

      } else {
        val initial = this.money
        val r = new scala.util.Random
        this.money = (this.money - bet + bet * (0.75 + r.nextDouble))
        if (initial >= this.money)
          "Aw crud. Maybe if I play again. I will win. Now I only have " + "%1.2f".format(this.money) + " euros."
        else
          "I won! Maybe I'll be able to afford better ingredients now. Now I have " + "%1.2f".format(this.money) + " euros."
      }
    } else {
      "I should try to enter a number"
    }
  }
  
  // Allows the player to pay for their products and warns them if they dont have enough money to pay.
  def cashier() = {
    if (this.totalOwed == 0.0){
      "Hmm. I didn't need to pay since I don't have anything to buy. Now I made myself look stupid infront of all these people."
      
    }else if (this.money >= this.totalOwed){ 
      this.money -= this.totalOwed 
      this.items.values.foreach(_.price = 0.0)
      this.totalOwed = 0.0
      "**You pay for the groceries**\nDamn that's really expensive. I should start looking for job so I can afford this lifestyle"
      
    }else{
      f"I have "+ "%1.2f".format(this.money) + " euros. But I need " + "%1.2f".format(this.totalOwed) + " euros. I need more money to pay for all of this. Maybe I should try my luck at the slot machine..."
    
    }
  }
  
  def help() = {
    
"""'go' moves the player to new locations, it must be used in combination with the right prepositions and location that are convieniently surrounded by apostrophes. Examples) 'go back home' or 'go to alepa'.
'get' picks up an item in the location and adds it to your inventory, the item it must be spelled correctly.
'drop' drops the item into your current location and removes it from your inventory.
'pay' works only at the checkout location in the game. It can be used by itself. Example) 'pay'
'bet' operates the slot machine when you are in its location, you can place bets with the money you have using this command. Example) 'bet 5' or 'bet 5.5'
'examine' can examine any object in the game closely. Including a 'wallet' every player has and cannot remove. Example) 'examine wallet'
'use' can only be called on the pot item. It uses the pot to combine the ingredients you have. It must be used like so... 'use pot'
'inventory' examines the current belongings of the player, excluding the wallet.
'quit' quits the game
'rest' rests 
 """

  }

  /** Returns a brief description of the player's state, for debugging purposes. */
  override def toString = "Now at: " + this.location.name


}


