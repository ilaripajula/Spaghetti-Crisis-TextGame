package o1.adventure

/** The class `Adventure` represents text adventure games. An adventure consists of a player and
  * a number of areas that make up the game world. It provides methods for playing the game one
  * turn at a time and for checking the state of the game.
  *
  * N.B. This version of the class has a lot of "hard-coded" information which pertain to a very
  * specific adventure game that involves a small trip through a twisted forest. All newly created
  * instances of class `Adventure` are identical to each other. To create other kinds of adventure
  * games, you will need to modify or replace the source code of this class. */
class Adventure {

  /** The title of the adventure game. */
  val title = "Spaghetti Crisis: A Student Adventure!"

  private val home      = new Area("Home", "HOME:\nAh! Home sweet home. The air is blessed with the sweet fragrance of my roommate's unwashed laundry.")
  private val kitchen = new Area("The Kitchen", "THE KITCHEN:\nSomeone should really clean those dishes, they've been sitting there for like a month. I'm too busy at the moment though.\nHere I can try to 'use' the pot if I'd like to.\n")
  private val alepa = new Area("Alepa", "ALEPA:\nI like this place, it's much cheaper than K-Market.")
  private val aisle2 = new Area("Aisle 2", "AISLE 2:\nThis looks like I could get the cheese from here.")
  private val aisle1    = new Area("Aisle 1", "AISLE 1:\nThis looks like I could get the minced meat from here!")
  private val aisle3      = new Area("Aisle 3", "AISLE 3:\nThis looks like where I can get the spaghetti.")
  private val slotMachine = new Area("Slot Machine", "SLOT MACHINE:\nMy good friend PikaPokeri! How much cash should I bet?\n\nSince I lost last time I have to win this time. Right?? Anyways, I need to win more money so I can eat properly!\nI should try 'bet 5' for example.")
  private val checkout        = new Area("Checkout", "CHECKOUT COUNTER:\nWell that line was long! But here I am.\nHere I should probably 'pay' for my groceries, unless I want to go to jail for theft or something silly.")
   
       home.setNeighbors(Vector("to alepa" -> alepa, "to the kitchen" -> kitchen))
       kitchen.setNeighbors(Vector("back home" -> home))
       alepa.setNeighbors(Vector("back home" -> home, "to aisle 1" -> aisle1, "to aisle 2" -> aisle2,"to aisle 3" -> aisle3))
       aisle2.setNeighbors(Vector("to checkout" -> checkout,"to aisle 1" -> aisle1,"to aisle 3" -> aisle3, "to the slot machine" -> slotMachine))
       aisle1.setNeighbors(Vector("to checkout" -> checkout,"to aisle 2" -> aisle2,"to aisle 3" -> aisle3, "to the slot machine" -> slotMachine))
       aisle3.setNeighbors(Vector("to checkout" -> checkout,"to aisle 2" -> aisle2,"to aisle 1" -> aisle1,"to the slot machine" -> slotMachine))
       checkout.setNeighbors(Vector("back home" -> home,"to the slot machine" -> slotMachine,"to aisle 1" -> aisle1, "to aisle 2" -> aisle2,"to aisle 3" -> aisle3))
       slotMachine.setNeighbors(Vector("to aisle 1" -> aisle1, "to aisle 2" -> aisle2,"to aisle 3" -> aisle3, "to checkout" -> checkout))
       
  kitchen.addItem(new Item("shopping list", 0.0, "Here is what I need to make the perfect spaghetti.\n1)Snellman's minced meat\n2)Barilla Spaghetti\n3)Börk-Börk Öst"))
  kitchen.addItem(new Item("pot",0.0, "A pot used for cooking spaghetti. A spaghetti pot."))
  
  aisle1.addItem(new Item("сочный фарш",1.922, "Russian Minced Meat? This is new. I guess those trade restrictions don't work both ways."))
  aisle1.addItem(new Item("snellman's minced meat",4.99, "premimum minced meat, a little expensive though"))
  aisle1.addItem(new Item("rainbow minced meat",2.99, "This should be perfect. You can always trust rainbow products."))

  
  aisle3.addItem(new Item("barilla spaghetti",2.99, "Authentic Italian pasta! Wait actually it says this was produced in Jyväskylä."))
  aisle3.addItem(new Item("macaroni",0.20, "Wow, I should get this some other time."))
  aisle3.addItem(new Item("x-tra spaghetti",0.99, "You can never go wrong with these cheap brands. A euro for 1Kg that a good deal if i've ever seen one."))
  
  aisle2.addItem(new Item("x-tra shredded cheese", 2.99, "This would save me a lot of time and I wouldn't have to do any dishes."))
  aisle2.addItem(new Item("oltermanni alkuperäinen",5.99, "Why do they keep raising the price of my favorite cheese! It was 5 euros last week I swear!"))
  aisle2.addItem(new Item("börk-börk ost", 3.99, "Swedish delicacy cheese. This should be perfect to replicating the täffä experience."))

  
  
  /** The character that the player controls in the game. */
  val player = new Player(home)
  
  /** Determines if the adventure is complete, that is, if the player has won. */
  def isComplete = this.player.hasCooked()

  /** Determines whether the player has won, lost, or quit, thereby ending the game. */
  def isOver = this.isComplete || this.player.hasQuit || this.player.isInJail() == false

  /** Returns a message that is to be displayed to the player at the beginning of the game. */
  def welcomeMessage = "Täffä's kitchen staff have all called in sick on a Wednesday because the crayfish party they attended yesterday was serving spoiled crayfish. Desperate to fulfill your weekly dose of Spaghetti, you must collect the ingredients and cook the meal for yourself. Navigate yourself to Alepa to collect just the right ingredients, get back home and cook the meal in the kitchen. Use your intuition and memory of Täffä's spaghetti to purchase exactly the right ingredients. If you purchase the wrong ingredients your hunger will not be satisfied and you will surely perish.\n\nUse command 'help' to view a tutorial. "


  /** Returns a message that is to be displayed to the player at the end of the game. The message
    * will be different depending on whether or not the player has completed their quest. */
  def goodbyeMessage = {
    if (this.isComplete)
      "You made your own tasty spaghetti! This calls for celebration!\nYOU WON!"
    else if (this.player.isInJail() == false)
      "Oh no! Locked in your jail cell starved of spaghetti, you collapse and weep like a child.\nGAME OVER!"
    else  // game over due to player quitting
      "Quitter!"
  }


  /** Plays a turn by executing the given in-game command, such as "go west". Returns a textual
    * report of what happened, or an error message if the command was unknown. In the latter
    * case, no turns elapse. */
  def playTurn(command: String) = {
    val action = new Action(command)
    val outcomeReport = action.execute(this.player)
    outcomeReport.getOrElse("Unknown command: \"" + command + "\".")
  }
}

